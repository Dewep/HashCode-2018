#!/bin/sh

node parse-input.js inputs/a_example.in inputs/a_example.json
node parse-input.js inputs/b_should_be_easy.in inputs/b_should_be_easy.json
node parse-input.js inputs/c_no_hurry.in inputs/c_no_hurry.json
node parse-input.js inputs/d_metropolis.in inputs/d_metropolis.json
node parse-input.js inputs/e_high_bonus.in inputs/e_high_bonus.json
